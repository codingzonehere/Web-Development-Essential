function changeStyle() {
  var button = document.getElementById("myButton");
  button.style.font-weight = 100;
}
