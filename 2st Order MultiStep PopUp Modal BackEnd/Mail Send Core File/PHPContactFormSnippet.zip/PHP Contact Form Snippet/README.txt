This is the PHP code for a basic contact form that was taken from the tutorial found at http://1stwebdesigner.com/php-contact-form-html/. Here are the steps to set up your contact form.

1. Create a form using HTML and CSS
2. Be sure that your <form> tag looks like this: <form action="mail.php" method="POST">
3. All fields that you want to send to your email should have a name. For example:
  <input type="text" placeholder="Name" name="name">. The name of the input is what the PHP will look for so make sure that the name of the input matches the $POST name in the PHP file.
4. Change the fields inside the PHP file to match the fields in your contact form. You can change the names but you must match the name of your form fields with the name in '' in the $_POST['name'] fields. For example, you could write $_POST['full-name'] but your input name for this field must also be name="full-name".
5. Change the email in $recipient = "someaddress@email.com"; to match the destination email for this contact form.
6. Upload all of your files to a server. This will not work on your local computer. It must be on a server set up to handle PHP (almost all commercial servers). Be sure to place mail.php in the same folder as the HTML page you placed the contact form.
7. Test your contact form.

Watch a tutorial video on how to create a custom contact form at:

[video URL here]
